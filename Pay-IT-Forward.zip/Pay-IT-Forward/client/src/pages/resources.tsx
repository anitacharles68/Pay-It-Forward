import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, BookOpen, Brain, Heart, Phone, ExternalLink, Download, Star } from "lucide-react";
import Navigation from "@/components/navigation";
import type { Resource } from "@shared/schema";

export default function Resources() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const { data: resources = [], isLoading } = useQuery({
    queryKey: ['/api/resources', activeCategory === "all" ? undefined : activeCategory],
    queryFn: () => {
      const params = activeCategory === "all" ? "" : `?category=${activeCategory}`;
      return fetch(`/api/resources${params}`).then(res => res.json());
    },
  });

  const categories = [
    { value: "all", label: "All Resources", icon: BookOpen, color: "text-primary" },
    { value: "coping_strategies", label: "Coping Strategies", icon: Brain, color: "text-blue-600" },
    { value: "articles", label: "Educational Articles", icon: BookOpen, color: "text-green-600" },
    { value: "meditations", label: "Guided Meditations", icon: Heart, color: "text-purple-600" },
    { value: "crisis_support", label: "Crisis Support", icon: Phone, color: "text-red-600" },
  ];

  const filteredResources = resources.filter((resource: Resource) => {
    const searchLower = searchTerm.toLowerCase();
    const titleMatch = resource.title.toLowerCase().includes(searchLower);
    const contentMatch = resource.content.toLowerCase().includes(searchLower);
    const tagMatch = resource.tags?.some(tag => tag.toLowerCase().includes(searchLower));
    
    return titleMatch || contentMatch || tagMatch;
  });

  const getCategoryInfo = (categoryValue: string) => {
    return categories.find(cat => cat.value === categoryValue) || categories[0];
  };

  const formatCategoryName = (category: string) => {
    return category.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  // Mock featured resources for demonstration
  const featuredResources = [
    {
      title: "5-Minute Breathing Exercise",
      description: "Quick relaxation technique for immediate stress relief",
      category: "coping_strategies",
      duration: "5 min",
      rating: 4.8,
    },
    {
      title: "Understanding Anxiety",
      description: "Comprehensive guide to anxiety disorders and management",
      category: "articles",
      readTime: "10 min read",
      rating: 4.9,
    },
    {
      title: "Sleep Meditation",
      description: "Guided meditation for better sleep and relaxation",
      category: "meditations",
      duration: "20 min",
      rating: 4.7,
    },
    {
      title: "Crisis Hotlines",
      description: "24/7 crisis support numbers and resources",
      category: "crisis_support",
      access: "Immediate",
      rating: 5.0,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="md:ml-64 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Mental Health Resources</h1>
          <p className="text-muted-foreground">
            Access evidence-based tools, guides, and support materials for your mental health journey
          </p>
        </div>

        {/* Search */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search resources by title, content, or tags..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                data-testid="input-search-resources"
              />
            </div>
          </CardContent>
        </Card>

        {/* Featured Resources */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Featured Resources</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {featuredResources.map((resource, index) => {
              const categoryInfo = getCategoryInfo(resource.category);
              const Icon = categoryInfo.icon;
              
              return (
                <Card key={index} className="card-hover cursor-pointer" data-testid={`featured-resource-${index}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3 mb-3">
                      <div className={`w-10 h-10 bg-muted/50 rounded-lg flex items-center justify-center`}>
                        <Icon className={`h-5 w-5 ${categoryInfo.color}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-sm mb-1 line-clamp-2">{resource.title}</h3>
                        <Badge variant="outline" className="text-xs">
                          {formatCategoryName(resource.category)}
                        </Badge>
                      </div>
                    </div>
                    
                    <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                      {resource.description}
                    </p>
                    
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1">
                        <Star className="h-3 w-3 text-yellow-500" />
                        <span>{resource.rating}</span>
                      </div>
                      <span className="text-muted-foreground">
                        {resource.duration || resource.readTime || resource.access}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Category Tabs */}
        <Tabs value={activeCategory} onValueChange={setActiveCategory} className="w-full">
          <TabsList className="grid grid-cols-5 w-full mb-8">
            {categories.map(category => {
              const Icon = category.icon;
              return (
                <TabsTrigger 
                  key={category.value} 
                  value={category.value}
                  className="flex items-center gap-2"
                  data-testid={`tab-${category.value}`}
                >
                  <Icon className="h-4 w-4" />
                  <span className="hidden sm:inline">{category.label}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          {categories.map(category => (
            <TabsContent key={category.value} value={category.value}>
              <div className="space-y-6">
                {/* Category Description */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <category.icon className={`h-6 w-6 ${category.color}`} />
                      <h2 className="text-xl font-bold">{category.label}</h2>
                    </div>
                    <p className="text-muted-foreground">
                      {category.value === "all" && "Browse all available mental health resources"}
                      {category.value === "coping_strategies" && "Practical techniques and strategies for managing stress, anxiety, and difficult emotions"}
                      {category.value === "articles" && "In-depth articles about mental health conditions, treatments, and wellness tips"}
                      {category.value === "meditations" && "Guided meditation sessions for relaxation, mindfulness, and emotional regulation"}
                      {category.value === "crisis_support" && "Immediate support resources and crisis intervention information"}
                    </p>
                  </CardContent>
                </Card>

                {/* Resources Grid */}
                {isLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[1, 2, 3, 4, 5, 6].map((i) => (
                      <Card key={i} className="animate-pulse">
                        <CardContent className="p-6">
                          <div className="space-y-3">
                            <div className="h-4 bg-muted rounded w-3/4" />
                            <div className="h-3 bg-muted rounded w-1/2" />
                            <div className="h-20 bg-muted rounded" />
                            <div className="h-8 bg-muted rounded w-1/3" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : filteredResources.length === 0 ? (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <BookOpen className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                      <h3 className="text-xl font-semibold mb-2">No Resources Found</h3>
                      <p className="text-muted-foreground">
                        {searchTerm 
                          ? "Try adjusting your search terms or browse different categories."
                          : "No resources available in this category yet. Check back soon for new content."
                        }
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredResources.map((resource: Resource) => (
                      <Card key={resource.id} className="card-hover" data-testid={`resource-card-${resource.id}`}>
                        <CardHeader>
                          <div className="flex items-start justify-between mb-2">
                            <Badge variant="outline" className="mb-2">
                              {formatCategoryName(resource.category)}
                            </Badge>
                          </div>
                          <CardTitle className="text-lg leading-tight" data-testid={`resource-title-${resource.id}`}>
                            {resource.title}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-muted-foreground mb-4 line-clamp-3" data-testid={`resource-content-${resource.id}`}>
                            {resource.content}
                          </p>
                          
                          {resource.tags && resource.tags.length > 0 && (
                            <div className="flex flex-wrap gap-1 mb-4">
                              {resource.tags.slice(0, 3).map((tag, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                              {resource.tags.length > 3 && (
                                <Badge variant="secondary" className="text-xs">
                                  +{resource.tags.length - 3}
                                </Badge>
                              )}
                            </div>
                          )}
                          
                          <div className="flex gap-2">
                            <Button size="sm" className="flex-1" data-testid={`button-view-resource-${resource.id}`}>
                              <BookOpen className="h-3 w-3 mr-1" />
                              View Resource
                            </Button>
                            <Button size="sm" variant="outline" data-testid={`button-share-resource-${resource.id}`}>
                              <ExternalLink className="h-3 w-3" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>

        {/* Help Section */}
        <Card className="mt-12 gradient-bg text-white">
          <CardContent className="p-8 text-center">
            <Phone className="h-12 w-12 mx-auto mb-4 text-accent" />
            <h2 className="text-2xl font-bold mb-4">Need Immediate Help?</h2>
            <p className="text-white/90 mb-6">
              If you're experiencing a mental health crisis, please reach out for immediate support.
            </p>
            <div className="grid md:grid-cols-3 gap-4 max-w-4xl mx-auto">
              <div className="bg-white/10 p-4 rounded-lg">
                <h3 className="font-bold mb-2">Crisis Text Line</h3>
                <p className="text-sm mb-2">Text HOME to 741741</p>
                <p className="text-xs text-white/70">24/7 crisis support</p>
              </div>
              <div className="bg-white/10 p-4 rounded-lg">
                <h3 className="font-bold mb-2">National Suicide Prevention</h3>
                <p className="text-sm mb-2">988 or 1-800-273-8255</p>
                <p className="text-xs text-white/70">24/7 lifeline</p>
              </div>
              <div className="bg-white/10 p-4 rounded-lg">
                <h3 className="font-bold mb-2">Emergency Services</h3>
                <p className="text-sm mb-2">911</p>
                <p className="text-xs text-white/70">For immediate danger</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
