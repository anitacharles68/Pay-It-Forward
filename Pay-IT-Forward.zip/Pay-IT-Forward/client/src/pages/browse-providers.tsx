import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, Users, UserRound, Star, Calendar, MessageCircle } from "lucide-react";
import { Link } from "wouter";
import Navigation from "@/components/navigation";
import ProviderCard from "@/components/provider-card";
import type { User } from "@shared/schema";

export default function BrowseProviders() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRole, setSelectedRole] = useState<string>("all");
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>("all");

  const { data: providers = [], isLoading } = useQuery({
    queryKey: ['/api/providers', selectedRole === "all" ? undefined : selectedRole, selectedSpecialty === "all" ? undefined : selectedSpecialty],
    queryFn: () => {
      const params = new URLSearchParams();
      if (selectedRole !== "all") params.append("role", selectedRole);
      if (selectedSpecialty !== "all") params.append("specialty", selectedSpecialty);
      
      return fetch(`/api/providers?${params.toString()}`)
        .then(res => res.json());
    },
  });

  const filteredProviders = providers.filter((provider: User) => {
    const searchLower = searchTerm.toLowerCase();
    const nameMatch = `${provider.firstName} ${provider.lastName}`.toLowerCase().includes(searchLower);
    const bioMatch = provider.bio?.toLowerCase().includes(searchLower);
    const specialtyMatch = provider.specialties?.some(s => s.toLowerCase().includes(searchLower));
    
    return nameMatch || bioMatch || specialtyMatch;
  });

  const specialties = [
    "Anxiety", "Depression", "Trauma", "PTSD", "Addiction", "Relationships", 
    "Grief", "Stress", "Bipolar", "OCD", "Eating Disorders", "ADHD"
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Find Your Support</h1>
          <p className="text-muted-foreground">
            Connect with licensed counselors and peer specialists who understand your journey
          </p>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search by name, specialty, or bio..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  data-testid="input-search"
                />
              </div>
              
              <Select value={selectedRole} onValueChange={setSelectedRole}>
                <SelectTrigger data-testid="select-role">
                  <SelectValue placeholder="Provider Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Providers</SelectItem>
                  <SelectItem value="counselor">Licensed Counselors</SelectItem>
                  <SelectItem value="peer_specialist">Peer Specialists</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedSpecialty} onValueChange={setSelectedSpecialty}>
                <SelectTrigger data-testid="select-specialty">
                  <SelectValue placeholder="Specialty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Specialties</SelectItem>
                  {specialties.map(specialty => (
                    <SelectItem key={specialty} value={specialty.toLowerCase()}>
                      {specialty}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button 
                variant="outline" 
                onClick={() => {
                  setSearchTerm("");
                  setSelectedRole("all");
                  setSelectedSpecialty("all");
                }}
                data-testid="button-clear-filters"
              >
                Clear Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Provider Type Tabs */}
        <div className="flex gap-4 mb-8">
          <Button 
            variant={selectedRole === "all" ? "default" : "outline"}
            onClick={() => setSelectedRole("all")}
            className="flex items-center gap-2"
            data-testid="button-all-providers"
          >
            <Users className="h-4 w-4" />
            All Providers ({providers.length})
          </Button>
          <Button 
            variant={selectedRole === "counselor" ? "default" : "outline"}
            onClick={() => setSelectedRole("counselor")}
            className="flex items-center gap-2"
            data-testid="button-counselors"
          >
            <UserRound className="h-4 w-4" />
            Counselors ({providers.filter((p: User) => p.role === 'counselor').length})
          </Button>
          <Button 
            variant={selectedRole === "peer_specialist" ? "default" : "outline"}
            onClick={() => setSelectedRole("peer_specialist")}
            className="flex items-center gap-2"
            data-testid="button-peer-specialists"
          >
            <Users className="h-4 w-4" />
            Peer Specialists ({providers.filter((p: User) => p.role === 'peer_specialist').length})
          </Button>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="w-16 h-16 bg-muted rounded-full" />
                    <div className="space-y-2">
                      <div className="h-4 bg-muted rounded w-24" />
                      <div className="h-3 bg-muted rounded w-32" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-3 bg-muted rounded" />
                    <div className="h-3 bg-muted rounded w-3/4" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Providers Grid */}
        {!isLoading && filteredProviders.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProviders.map((provider: User) => (
              <ProviderCard key={provider.id} provider={provider} />
            ))}
          </div>
        )}

        {/* Empty State */}
        {!isLoading && filteredProviders.length === 0 && (
          <Card className="text-center py-12">
            <CardContent>
              <Users className="h-16 w-16 mx-auto text-muted-foreground mb-4 opacity-50" />
              <h3 className="text-xl font-semibold mb-2">No Providers Found</h3>
              <p className="text-muted-foreground mb-6">
                {searchTerm || selectedRole !== "all" || selectedSpecialty !== "all" 
                  ? "Try adjusting your search criteria or filters."
                  : "No providers are currently available. Please check back later."
                }
              </p>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSearchTerm("");
                  setSelectedRole("all");
                  setSelectedSpecialty("all");
                }}
                data-testid="button-reset-search"
              >
                Reset Search
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Help Section */}
        <Card className="mt-12 gradient-bg text-white">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Need Help Choosing?</h2>
            <p className="text-white/90 mb-6">
              Not sure whether to choose a licensed counselor or peer specialist? We're here to help you find the right support.
            </p>
            <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              <div className="bg-white/10 p-6 rounded-lg">
                <UserRound className="h-8 w-8 mb-3 mx-auto" />
                <h3 className="font-bold mb-2">Licensed Counselors</h3>
                <p className="text-sm text-white/80">
                  Professional therapy for diagnosed conditions, evidence-based treatment, insurance coverage available
                </p>
              </div>
              <div className="bg-white/10 p-6 rounded-lg">
                <Users className="h-8 w-8 mb-3 mx-auto" />
                <h3 className="font-bold mb-2">Peer Specialists</h3>
                <p className="text-sm text-white/80">
                  Support from lived experience, mentoring, affordable guidance, flexible communication
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
