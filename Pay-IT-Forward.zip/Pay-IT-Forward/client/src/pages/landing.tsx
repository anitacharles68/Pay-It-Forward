import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Calendar, Shield, Clock, Users, UserRound, CheckCircle, Star, Brain, BookOpen, Phone } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Heart className="text-primary text-2xl" />
              <span className="text-xl font-bold text-foreground">Pay It Forward</span>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <a href="#how-it-works" className="text-muted-foreground hover:text-foreground transition-colors">How It Works</a>
              <a href="#support-options" className="text-muted-foreground hover:text-foreground transition-colors">Support Options</a>
              <a href="#pricing" className="text-muted-foreground hover:text-foreground transition-colors">Pricing</a>
              <a href="#resources" className="text-muted-foreground hover:text-foreground transition-colors">Resources</a>
            </nav>
            
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                onClick={() => window.location.href = '/api/login'}
                data-testid="button-sign-in"
              >
                Sign In
              </Button>
              <Button 
                onClick={() => window.location.href = '/api/login'}
                data-testid="button-get-started"
              >
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="gradient-bg text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-6xl font-bold leading-tight mb-6">
                Mental Health Support for <span className="text-accent">Everyone</span>
              </h1>
              <p className="text-xl mb-8 text-white/90" data-testid="text-hero-description">
                Connect with licensed counselors and peer specialists. Most sessions are free thanks to insurance, grants, and donations. Because everyone deserves support.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button 
                  className="bg-white text-primary px-8 py-4 rounded-lg font-semibold hover:bg-white/95 transition-colors"
                  onClick={() => window.location.href = '/api/login'}
                  data-testid="button-book-session"
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  Book Session Now
                </Button>
                <Button 
                  variant="outline"
                  className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-primary transition-colors"
                  onClick={() => window.location.href = '/api/login'}
                  data-testid="button-browse-counselors"
                >
                  Browse Counselors
                </Button>
              </div>
              
              <div className="flex items-center space-x-6 text-sm text-white/80">
                <div className="flex items-center">
                  <Shield className="mr-2 h-4 w-4" />
                  HIPAA Compliant
                </div>
                <div className="flex items-center">
                  <Clock className="mr-2 h-4 w-4" />
                  24/7 Peer Support
                </div>
                <div className="flex items-center">
                  <Users className="mr-2 h-4 w-4" />
                  Licensed Professionals
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Diverse group in supportive therapy session" 
                className="rounded-2xl shadow-2xl w-full"
                data-testid="img-hero"
              />
              
              <div className="absolute -top-4 -left-4 bg-white text-primary p-4 rounded-xl shadow-lg">
                <div className="text-2xl font-bold" data-testid="text-success-rate">95%</div>
                <div className="text-sm text-muted-foreground">Success Rate</div>
              </div>
              
              <div className="absolute -bottom-4 -right-4 bg-white text-secondary p-4 rounded-xl shadow-lg">
                <div className="text-2xl font-bold" data-testid="text-lives-helped">10K+</div>
                <div className="text-sm text-muted-foreground">Lives Helped</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Support Options */}
      <section id="support-options" className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">Two Levels of Support</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Choose the type of support that feels right for you. Both options are designed to provide meaningful help when you need it most.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Licensed Counselors Card */}
            <Card className="card-hover">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <UserRound className="text-primary text-2xl" />
                  </div>
                  <h3 className="text-2xl font-bold text-foreground mb-2">Licensed Counselors</h3>
                  <p className="text-muted-foreground">Professional therapy with licensed mental health professionals</p>
                </div>
                
                <div className="space-y-4 mb-8">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="text-primary mt-1 h-5 w-5" />
                    <div>
                      <div className="font-semibold">Professional Therapy</div>
                      <div className="text-sm text-muted-foreground">Evidence-based treatment approaches</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="text-primary mt-1 h-5 w-5" />
                    <div>
                      <div className="font-semibold">Specialized Care</div>
                      <div className="text-sm text-muted-foreground">Depression, anxiety, trauma, and more</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="text-primary mt-1 h-5 w-5" />
                    <div>
                      <div className="font-semibold">Insurance Billing</div>
                      <div className="text-sm text-muted-foreground">Most sessions covered by insurance</div>
                    </div>
                  </div>
                </div>
                
                <div className="text-center border-t border-border pt-6">
                  <div className="text-3xl font-bold text-primary mb-2" data-testid="text-counselor-price">$50-70</div>
                  <div className="text-muted-foreground mb-4">per session (often covered by insurance)</div>
                  <Button 
                    className="w-full"
                    onClick={() => window.location.href = '/api/login'}
                    data-testid="button-find-counselor"
                  >
                    Find a Counselor
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* Peer Specialists Card */}
            <Card className="card-hover">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="text-secondary text-2xl" />
                  </div>
                  <h3 className="text-2xl font-bold text-foreground mb-2">Peer Specialists</h3>
                  <p className="text-muted-foreground">Support from trained individuals with lived experience</p>
                </div>
                
                <div className="space-y-4 mb-8">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="text-secondary mt-1 h-5 w-5" />
                    <div>
                      <div className="font-semibold">Lived Experience</div>
                      <div className="text-sm text-muted-foreground">Connect with someone who understands</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="text-secondary mt-1 h-5 w-5" />
                    <div>
                      <div className="font-semibold">Peer Mentoring</div>
                      <div className="text-sm text-muted-foreground">Guidance through recovery journey</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="text-secondary mt-1 h-5 w-5" />
                    <div>
                      <div className="font-semibold">Flexible Support</div>
                      <div className="text-sm text-muted-foreground">Chat, calls, or group sessions</div>
                    </div>
                  </div>
                </div>
                
                <div className="text-center border-t border-border pt-6">
                  <div className="text-3xl font-bold text-secondary mb-2" data-testid="text-peer-price">$20</div>
                  <div className="text-muted-foreground mb-4">per hour (often free with assistance)</div>
                  <Button 
                    className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90"
                    onClick={() => window.location.href = '/api/login'}
                    data-testid="button-connect-peers"
                  >
                    Connect with Peers
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">How It Works</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Getting started is simple. We've designed our platform to remove barriers and connect you with the right support quickly.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="text-primary text-2xl" />
              </div>
              <h3 className="text-xl font-bold mb-4">1. Create Your Profile</h3>
              <p className="text-muted-foreground">
                Tell us about yourself and what kind of support you're looking for. All information is kept private and secure.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="text-secondary text-2xl" />
              </div>
              <h3 className="text-xl font-bold mb-4">2. Find Your Match</h3>
              <p className="text-muted-foreground">
                Browse licensed counselors and peer specialists. Filter by specialty, availability, and communication style.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Heart className="text-accent text-2xl" />
              </div>
              <h3 className="text-xl font-bold mb-4">3. Start Your Journey</h3>
              <p className="text-muted-foreground">
                Book sessions, join community circles, or start messaging. Your mental health journey begins here.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Resources Section */}
      <section id="resources" className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">Mental Health Resources</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Access free resources, coping strategies, and educational content to support your mental health journey.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center card-hover">
              <CardContent className="p-6">
                <Brain className="text-primary text-3xl mb-4 mx-auto" />
                <h3 className="font-bold mb-2">Coping Strategies</h3>
                <p className="text-sm text-muted-foreground">Evidence-based techniques for managing stress and anxiety</p>
              </CardContent>
            </Card>
            
            <Card className="text-center card-hover">
              <CardContent className="p-6">
                <BookOpen className="text-secondary text-3xl mb-4 mx-auto" />
                <h3 className="font-bold mb-2">Educational Articles</h3>
                <p className="text-sm text-muted-foreground">Learn about mental health conditions and treatment options</p>
              </CardContent>
            </Card>
            
            <Card className="text-center card-hover">
              <CardContent className="p-6">
                <Heart className="text-accent text-3xl mb-4 mx-auto" />
                <h3 className="font-bold mb-2">Guided Meditations</h3>
                <p className="text-sm text-muted-foreground">Mindfulness exercises for relaxation and self-care</p>
              </CardContent>
            </Card>
            
            <Card className="text-center card-hover">
              <CardContent className="p-6">
                <Phone className="text-destructive text-3xl mb-4 mx-auto" />
                <h3 className="font-bold mb-2">Crisis Support</h3>
                <p className="text-sm text-muted-foreground">24/7 crisis hotlines and emergency resources</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg text-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-8 text-white/90">
            Take the first step towards better mental health. Our community is here to support you every step of the way.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <Button 
              className="bg-white text-primary px-8 py-4 rounded-lg font-semibold hover:bg-white/95 transition-colors"
              onClick={() => window.location.href = '/api/login'}
              data-testid="button-create-account"
            >
              <Users className="mr-2 h-4 w-4" />
              Create Account
            </Button>
            <Button 
              variant="outline"
              className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-primary transition-colors"
              data-testid="button-learn-more"
            >
              Learn More
            </Button>
          </div>
          
          <p className="text-sm text-white/70 mt-6">
            Free to sign up • Insurance accepted • HIPAA compliant
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <Heart className="text-accent text-2xl" />
                <span className="text-xl font-bold">Pay It Forward</span>
              </div>
              <p className="text-white/70 mb-6">
                Making mental health support accessible, affordable, and stigma-free for everyone.
              </p>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">For Users</h4>
              <ul className="space-y-2 text-white/70">
                <li><a href="#" className="hover:text-white">Find a Counselor</a></li>
                <li><a href="#" className="hover:text-white">Peer Support</a></li>
                <li><a href="#" className="hover:text-white">Support Groups</a></li>
                <li><a href="#" className="hover:text-white">Resources</a></li>
                <li><a href="#" className="hover:text-white">Crisis Support</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">For Providers</h4>
              <ul className="space-y-2 text-white/70">
                <li><a href="#" className="hover:text-white">Join as Counselor</a></li>
                <li><a href="#" className="hover:text-white">Become Peer Specialist</a></li>
                <li><a href="#" className="hover:text-white">Provider Resources</a></li>
                <li><a href="#" className="hover:text-white">Training Materials</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">Company</h4>
              <ul className="space-y-2 text-white/70">
                <li><a href="#" className="hover:text-white">About Us</a></li>
                <li><a href="#" className="hover:text-white">Our Mission</a></li>
                <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-white/20 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-white/70 text-sm">© 2024 Pay It Forward. All rights reserved.</p>
            <div className="flex items-center space-x-6 text-sm text-white/70 mt-4 md:mt-0">
              <div className="flex items-center">
                <Shield className="mr-2 h-4 w-4" />
                HIPAA Compliant
              </div>
              <div className="flex items-center">
                <Shield className="mr-2 h-4 w-4" />
                SSL Secured
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
