import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Calendar, Clock, DollarSign, Users, CheckCircle, XCircle, MoreHorizontal } from "lucide-react";
import { Link } from "wouter";
import Navigation from "@/components/navigation";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Appointment } from "@shared/schema";

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("upcoming");

  const { data: clientAppointments = [], isLoading: clientLoading } = useQuery({
    queryKey: ['/api/appointments', { role: 'client' }],
    queryFn: () => fetch('/api/appointments?role=client').then(res => res.json()),
    enabled: !!user,
  });

  const { data: providerAppointments = [], isLoading: providerLoading } = useQuery({
    queryKey: ['/api/appointments', { role: 'provider' }],
    queryFn: () => fetch('/api/appointments?role=provider').then(res => res.json()),
    enabled: !!user && (user.role === 'counselor' || user.role === 'peer_specialist'),
  });

  const updateAppointmentMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      await apiRequest('PUT', `/api/appointments/${id}/status`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Appointment Updated",
        description: "The appointment status has been updated.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update appointment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'default';
      case 'completed': return 'secondary';
      case 'cancelled': return 'destructive';
      default: return 'outline';
    }
  };

  const getAppointmentsByStatus = (appointments: Appointment[], status: string) => {
    const now = new Date();
    switch (status) {
      case 'upcoming':
        return appointments.filter(apt => 
          apt.status === 'scheduled' && new Date(apt.startTime) > now
        );
      case 'past':
        return appointments.filter(apt => 
          apt.status === 'completed' || (apt.status === 'scheduled' && new Date(apt.startTime) <= now)
        );
      case 'cancelled':
        return appointments.filter(apt => apt.status === 'cancelled');
      default:
        return appointments;
    }
  };

  const AppointmentCard = ({ appointment, isProvider = false }: { appointment: Appointment; isProvider?: boolean }) => (
    <Card key={appointment.id} className="mb-4" data-testid={`appointment-card-${appointment.id}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="font-semibold mb-1" data-testid={`appointment-title-${appointment.id}`}>
              {isProvider ? `Session with Client` : `Session with Provider`}
            </h3>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                {new Date(appointment.startTime).toLocaleDateString()}
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {new Date(appointment.startTime).toLocaleTimeString()} - {new Date(appointment.endTime).toLocaleTimeString()}
              </div>
              {appointment.amount && (
                <div className="flex items-center gap-1">
                  <DollarSign className="h-3 w-3" />
                  ${appointment.amount}
                </div>
              )}
            </div>
          </div>
          <Badge variant={getStatusColor(appointment.status)} data-testid={`appointment-status-${appointment.id}`}>
            {appointment.status}
          </Badge>
        </div>

        {appointment.notes && (
          <p className="text-sm text-muted-foreground mb-3" data-testid={`appointment-notes-${appointment.id}`}>
            {appointment.notes}
          </p>
        )}

        <div className="flex gap-2">
          {appointment.status === 'scheduled' && new Date(appointment.startTime) > new Date() && (
            <>
              {isProvider && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => updateAppointmentMutation.mutate({ id: appointment.id, status: 'completed' })}
                  disabled={updateAppointmentMutation.isPending}
                  data-testid={`button-complete-${appointment.id}`}
                >
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Mark Complete
                </Button>
              )}
              <Button
                size="sm"
                variant="outline"
                onClick={() => updateAppointmentMutation.mutate({ id: appointment.id, status: 'cancelled' })}
                disabled={updateAppointmentMutation.isPending}
                data-testid={`button-cancel-${appointment.id}`}
              >
                <XCircle className="h-3 w-3 mr-1" />
                Cancel
              </Button>
            </>
          )}
          
          {appointment.status === 'completed' && (
            <div className="text-sm text-muted-foreground">
              Session completed
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );

  const AppointmentsList = ({ appointments, isProvider = false, title }: { appointments: Appointment[]; isProvider?: boolean; title: string }) => (
    <div>
      <h3 className="font-semibold mb-4 flex items-center gap-2">
        <Calendar className="h-5 w-5" />
        {title} ({appointments.length})
      </h3>
      {appointments.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Calendar className="h-12 w-12 mx-auto mb-3 text-muted-foreground opacity-50" />
            <p className="text-muted-foreground">No appointments found</p>
            {!isProvider && (
              <Link href="/browse">
                <Button variant="outline" className="mt-3" data-testid="button-book-session">
                  Book Your First Session
                </Button>
              </Link>
            )}
          </CardContent>
        </Card>
      ) : (
        <div>
          {appointments.map(appointment => (
            <AppointmentCard key={appointment.id} appointment={appointment} isProvider={isProvider} />
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="md:ml-64 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard</h1>
          <p className="text-muted-foreground">
            Manage your appointments and view your activity
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Upcoming</p>
                  <p className="text-2xl font-bold" data-testid="stat-upcoming">
                    {getAppointmentsByStatus(clientAppointments, 'upcoming').length}
                  </p>
                </div>
                <Calendar className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Completed</p>
                  <p className="text-2xl font-bold" data-testid="stat-completed">
                    {getAppointmentsByStatus(clientAppointments, 'past').length}
                  </p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">This Month</p>
                  <p className="text-2xl font-bold" data-testid="stat-this-month">
                    {clientAppointments.filter((apt: Appointment) => {
                      const aptDate = new Date(apt.startTime);
                      const now = new Date();
                      return aptDate.getMonth() === now.getMonth() && aptDate.getFullYear() === now.getFullYear();
                    }).length}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-secondary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Spent</p>
                  <p className="text-2xl font-bold" data-testid="stat-total-spent">
                    ${clientAppointments.reduce((sum: number, apt: Appointment) => 
                      sum + (parseFloat(apt.amount || '0')), 0
                    ).toFixed(0)}
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-accent" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Appointments Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 w-full max-w-md">
            <TabsTrigger value="upcoming" data-testid="tab-upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="past" data-testid="tab-past">Past</TabsTrigger>
            <TabsTrigger value="cancelled" data-testid="tab-cancelled">Cancelled</TabsTrigger>
          </TabsList>

          <div className="mt-6">
            {/* Client Appointments */}
            <TabsContent value="upcoming">
              <AppointmentsList 
                appointments={getAppointmentsByStatus(clientAppointments, 'upcoming')}
                title="Upcoming Sessions"
              />
            </TabsContent>

            <TabsContent value="past">
              <AppointmentsList 
                appointments={getAppointmentsByStatus(clientAppointments, 'past')}
                title="Past Sessions"
              />
            </TabsContent>

            <TabsContent value="cancelled">
              <AppointmentsList 
                appointments={getAppointmentsByStatus(clientAppointments, 'cancelled')}
                title="Cancelled Sessions"
              />
            </TabsContent>
          </div>
        </Tabs>

        {/* Provider Appointments Section */}
        {(user?.role === 'counselor' || user?.role === 'peer_specialist') && (
          <div className="mt-12">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Provider Dashboard
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="provider-upcoming" className="w-full">
                  <TabsList className="grid grid-cols-3 w-full max-w-md">
                    <TabsTrigger value="provider-upcoming">Upcoming</TabsTrigger>
                    <TabsTrigger value="provider-past">Past</TabsTrigger>
                    <TabsTrigger value="provider-cancelled">Cancelled</TabsTrigger>
                  </TabsList>

                  <div className="mt-6">
                    <TabsContent value="provider-upcoming">
                      <AppointmentsList 
                        appointments={getAppointmentsByStatus(providerAppointments, 'upcoming')}
                        isProvider={true}
                        title="Client Sessions"
                      />
                    </TabsContent>

                    <TabsContent value="provider-past">
                      <AppointmentsList 
                        appointments={getAppointmentsByStatus(providerAppointments, 'past')}
                        isProvider={true}
                        title="Completed Sessions"
                      />
                    </TabsContent>

                    <TabsContent value="provider-cancelled">
                      <AppointmentsList 
                        appointments={getAppointmentsByStatus(providerAppointments, 'cancelled')}
                        isProvider={true}
                        title="Cancelled Sessions"
                      />
                    </TabsContent>
                  </div>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
