import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Calendar, Clock, DollarSign, User, ArrowLeft, CheckCircle } from "lucide-react";
import { Link } from "wouter";
import Navigation from "@/components/navigation";
import AppointmentCalendar from "@/components/appointment-calendar";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { User as UserType } from "@shared/schema";

export default function Booking() {
  const { providerId } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string>("");
  const [notes, setNotes] = useState("");
  const [bookingStep, setBookingStep] = useState<'select' | 'confirm' | 'payment'>('select');

  const { data: provider, isLoading: providerLoading } = useQuery({
    queryKey: ['/api/providers', providerId],
    queryFn: () => fetch(`/api/providers/${providerId}`).then(res => res.json()),
    enabled: !!providerId,
  });

  const createAppointmentMutation = useMutation({
    mutationFn: async (appointmentData: any) => {
      const response = await apiRequest('POST', '/api/appointments', appointmentData);
      return response.json();
    },
    onSuccess: (appointment) => {
      toast({
        title: "Appointment Booked",
        description: "Your session has been successfully scheduled.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
      
      // If payment is required, proceed to payment
      if (appointment.amount && parseFloat(appointment.amount) > 0) {
        setBookingStep('payment');
      } else {
        // Free session, redirect to dashboard
        window.location.href = '/dashboard';
      }
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Booking Failed",
        description: "Failed to book appointment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleBooking = () => {
    if (!selectedDate || !selectedTime || !provider) return;

    const [hours, minutes] = selectedTime.split(':');
    const startTime = new Date(selectedDate);
    startTime.setHours(parseInt(hours), parseInt(minutes), 0, 0);
    
    const endTime = new Date(startTime);
    endTime.setHours(endTime.getHours() + 1); // 1-hour sessions

    const sessionType = provider.role === 'counselor' ? 'counseling' : 'peer_support';
    const amount = provider.hourlyRate || (provider.role === 'counselor' ? '60' : '20');

    createAppointmentMutation.mutate({
      providerId: provider.id,
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      sessionType,
      amount,
      notes: notes.trim() || undefined,
    });
  };

  const getRoleDisplay = (role: string) => {
    switch (role) {
      case 'counselor': return 'Licensed Counselor';
      case 'peer_specialist': return 'Peer Specialist';
      default: return role;
    }
  };

  const getSessionRate = () => {
    if (!provider) return null;
    
    if (provider.hourlyRate) {
      return provider.role === 'counselor' 
        ? `$${provider.hourlyRate}/session`
        : `$${provider.hourlyRate}/hour`;
    }
    
    return provider.role === 'counselor' ? '$50-70/session' : '$20/hour';
  };

  if (providerLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="md:ml-64 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-1/3" />
            <div className="h-64 bg-muted rounded" />
            <div className="h-32 bg-muted rounded" />
          </div>
        </div>
      </div>
    );
  }

  if (!provider) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="md:ml-64 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card>
            <CardContent className="p-8 text-center">
              <h2 className="text-xl font-bold mb-2">Provider Not Found</h2>
              <p className="text-muted-foreground mb-4">
                The provider you're looking for doesn't exist or is no longer available.
              </p>
              <Link href="/browse">
                <Button data-testid="button-browse-providers">Browse Providers</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="md:ml-64 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link href="/browse">
            <Button variant="ghost" className="mb-4" data-testid="button-back">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Providers
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-foreground mb-2">Book a Session</h1>
          <p className="text-muted-foreground">
            Schedule your appointment with {provider.firstName} {provider.lastName}
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Provider Info */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  {provider.profileImageUrl ? (
                    <img 
                      src={provider.profileImageUrl} 
                      alt={`${provider.firstName} ${provider.lastName}`}
                      className="w-24 h-24 rounded-full object-cover mx-auto mb-4"
                      data-testid="img-provider-photo"
                    />
                  ) : (
                    <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <User className="h-12 w-12 text-primary" />
                    </div>
                  )}
                  
                  <h2 className="text-xl font-bold mb-2" data-testid="text-provider-name">
                    {provider.firstName} {provider.lastName}
                  </h2>
                  <Badge variant={provider.role === 'counselor' ? 'default' : 'secondary'} className="mb-3">
                    {getRoleDisplay(provider.role)}
                  </Badge>
                  
                  {provider.licenseNumber && (
                    <p className="text-sm text-muted-foreground mb-3">
                      License: {provider.licenseNumber}
                    </p>
                  )}
                </div>

                {provider.bio && (
                  <div className="mb-4">
                    <h3 className="font-semibold mb-2">About</h3>
                    <p className="text-sm text-muted-foreground" data-testid="text-provider-bio">
                      {provider.bio}
                    </p>
                  </div>
                )}

                {provider.specialties && provider.specialties.length > 0 && (
                  <div className="mb-4">
                    <h3 className="font-semibold mb-2">Specialties</h3>
                    <div className="flex flex-wrap gap-1">
                      {provider.specialties.map((specialty, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <div className="border-t pt-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Session Rate:</span>
                    <span className="font-semibold" data-testid="text-session-rate">
                      {getSessionRate()}
                    </span>
                  </div>
                  {provider.yearsExperience && (
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Experience:</span>
                      <span className="font-semibold">{provider.yearsExperience}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Booking Form */}
          <div className="lg:col-span-2">
            {bookingStep === 'select' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Select Date & Time
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <AppointmentCalendar
                    selectedDate={selectedDate}
                    selectedTime={selectedTime}
                    onDateSelect={setSelectedDate}
                    onTimeSelect={setSelectedTime}
                    providerId={providerId || ''}
                  />

                  <div>
                    <Label htmlFor="notes">Session Notes (Optional)</Label>
                    <Textarea
                      id="notes"
                      placeholder="What would you like to focus on in this session? Any specific concerns or goals?"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={3}
                      data-testid="textarea-session-notes"
                    />
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t">
                    <div>
                      {selectedDate && selectedTime && (
                        <div className="text-sm text-muted-foreground">
                          <div className="flex items-center gap-1 mb-1">
                            <Calendar className="h-3 w-3" />
                            {selectedDate.toLocaleDateString()}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {selectedTime}
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <Button
                      onClick={() => setBookingStep('confirm')}
                      disabled={!selectedDate || !selectedTime}
                      data-testid="button-continue-booking"
                    >
                      Continue
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {bookingStep === 'confirm' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5" />
                    Confirm Booking
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-muted/50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-3">Booking Summary</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Provider:</span>
                        <span className="font-medium">
                          {provider.firstName} {provider.lastName}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Session Type:</span>
                        <span className="font-medium">
                          {provider.role === 'counselor' ? 'Counseling Session' : 'Peer Support'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Date:</span>
                        <span className="font-medium">
                          {selectedDate?.toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Time:</span>
                        <span className="font-medium">
                          {selectedTime} (1 hour)
                        </span>
                      </div>
                      <div className="flex justify-between border-t pt-2">
                        <span>Total:</span>
                        <span className="font-bold text-lg">
                          {getSessionRate()}
                        </span>
                      </div>
                    </div>

                    {notes && (
                      <div className="mt-4 pt-4 border-t">
                        <h4 className="font-medium mb-2">Session Notes:</h4>
                        <p className="text-sm text-muted-foreground">{notes}</p>
                      </div>
                    )}
                  </div>

                  <div className="flex gap-4">
                    <Button
                      variant="outline"
                      onClick={() => setBookingStep('select')}
                      data-testid="button-back-to-select"
                    >
                      Back
                    </Button>
                    <Button
                      onClick={handleBooking}
                      disabled={createAppointmentMutation.isPending}
                      className="flex-1"
                      data-testid="button-confirm-booking"
                    >
                      {createAppointmentMutation.isPending ? (
                        <div className="flex items-center gap-2">
                          <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                          Booking...
                        </div>
                      ) : (
                        'Confirm Booking'
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {bookingStep === 'payment' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    Payment Required
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">
                    Your appointment has been booked. Please complete payment to confirm your session.
                  </p>
                  <Link href="/checkout">
                    <Button className="w-full" data-testid="button-proceed-payment">
                      Proceed to Payment
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
