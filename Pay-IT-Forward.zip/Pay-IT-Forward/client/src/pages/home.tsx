import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart, Calendar, MessageCircle, BookOpen, Users, Clock } from "lucide-react";
import { Link } from "wouter";
import Navigation from "@/components/navigation";

export default function Home() {
  const { user } = useAuth();

  const { data: upcomingAppointments = [], isLoading: appointmentsLoading } = useQuery({
    queryKey: ['/api/appointments'],
    enabled: !!user,
  });

  const { data: conversations = [], isLoading: conversationsLoading } = useQuery({
    queryKey: ['/api/conversations'],
    enabled: !!user,
  });

  const { data: recentResources = [], isLoading: resourcesLoading } = useQuery({
    queryKey: ['/api/resources'],
    enabled: !!user,
  });

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 17) return "Good afternoon";
    return "Good evening";
  };

  const getRoleDisplay = (role: string) => {
    switch (role) {
      case 'counselor': return 'Licensed Counselor';
      case 'peer_specialist': return 'Peer Specialist';
      default: return 'Client';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="text-welcome">
            {getGreeting()}, {user?.firstName || 'Welcome'}!
          </h1>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" data-testid="badge-user-role">
              {getRoleDisplay(user?.role || 'client')}
            </Badge>
            {user?.role !== 'client' && (
              <Badge variant="outline" className={user?.isAvailable ? "border-green-500 text-green-600" : "border-red-500 text-red-600"}>
                {user?.isAvailable ? 'Available' : 'Unavailable'}
              </Badge>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="card-hover cursor-pointer" onClick={() => window.location.href = '/browse'}>
            <CardContent className="p-6 text-center">
              <Users className="h-8 w-8 text-primary mx-auto mb-3" />
              <h3 className="font-semibold mb-1">Find Support</h3>
              <p className="text-sm text-muted-foreground">Browse counselors and peer specialists</p>
            </CardContent>
          </Card>

          <Card className="card-hover cursor-pointer" onClick={() => window.location.href = '/messages'}>
            <CardContent className="p-6 text-center">
              <MessageCircle className="h-8 w-8 text-secondary mx-auto mb-3" />
              <h3 className="font-semibold mb-1">Messages</h3>
              <p className="text-sm text-muted-foreground">Connect with your support network</p>
            </CardContent>
          </Card>

          <Card className="card-hover cursor-pointer" onClick={() => window.location.href = '/dashboard'}>
            <CardContent className="p-6 text-center">
              <Calendar className="h-8 w-8 text-accent mx-auto mb-3" />
              <h3 className="font-semibold mb-1">Appointments</h3>
              <p className="text-sm text-muted-foreground">Manage your sessions</p>
            </CardContent>
          </Card>

          <Card className="card-hover cursor-pointer" onClick={() => window.location.href = '/resources'}>
            <CardContent className="p-6 text-center">
              <BookOpen className="h-8 w-8 text-purple-600 mx-auto mb-3" />
              <h3 className="font-semibold mb-1">Resources</h3>
              <p className="text-sm text-muted-foreground">Mental health tools and guides</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Upcoming Appointments */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Upcoming Appointments
              </CardTitle>
            </CardHeader>
            <CardContent>
              {appointmentsLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />
                  ))}
                </div>
              ) : upcomingAppointments.length > 0 ? (
                <div className="space-y-3">
                  {upcomingAppointments.slice(0, 3).map((appointment: any) => (
                    <div key={appointment.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg" data-testid={`appointment-${appointment.id}`}>
                      <div>
                        <div className="font-medium">Session with Provider</div>
                        <div className="text-sm text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {new Date(appointment.startTime).toLocaleDateString()} at {new Date(appointment.startTime).toLocaleTimeString()}
                        </div>
                      </div>
                      <Badge variant={appointment.status === 'scheduled' ? 'default' : 'secondary'}>
                        {appointment.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>No upcoming appointments</p>
                  <Link href="/browse">
                    <Button variant="outline" className="mt-3" data-testid="button-book-appointment">
                      Book Your First Session
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Messages */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5" />
                Recent Messages
              </CardTitle>
            </CardHeader>
            <CardContent>
              {conversationsLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />
                  ))}
                </div>
              ) : conversations.length > 0 ? (
                <div className="space-y-3">
                  {conversations.slice(0, 3).map((conversation: any) => (
                    <div key={conversation.user.id} className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg hover:bg-muted/70 cursor-pointer" data-testid={`conversation-${conversation.user.id}`}>
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                        <Users className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium truncate">
                          {conversation.user.firstName} {conversation.user.lastName}
                        </div>
                        <div className="text-sm text-muted-foreground truncate">
                          {conversation.lastMessage.content}
                        </div>
                      </div>
                      {conversation.unreadCount > 0 && (
                        <Badge variant="destructive" className="text-xs">
                          {conversation.unreadCount}
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <MessageCircle className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>No messages yet</p>
                  <Link href="/browse">
                    <Button variant="outline" className="mt-3" data-testid="button-start-conversation">
                      Connect with a Provider
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Resources */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Helpful Resources
              </CardTitle>
            </CardHeader>
            <CardContent>
              {resourcesLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />
                  ))}
                </div>
              ) : recentResources.length > 0 ? (
                <div className="space-y-3">
                  {recentResources.slice(0, 3).map((resource: any) => (
                    <div key={resource.id} className="p-3 bg-muted/50 rounded-lg hover:bg-muted/70 cursor-pointer" data-testid={`resource-${resource.id}`}>
                      <div className="font-medium mb-1">{resource.title}</div>
                      <Badge variant="outline" className="text-xs">
                        {resource.category.replace('_', ' ')}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <BookOpen className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>Explore mental health resources</p>
                  <Link href="/resources">
                    <Button variant="outline" className="mt-3" data-testid="button-browse-resources">
                      Browse Resources
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Call to Action */}
        <Card className="mt-8 gradient-bg text-white">
          <CardContent className="p-8 text-center">
            <Heart className="h-12 w-12 mx-auto mb-4 text-accent" />
            <h2 className="text-2xl font-bold mb-2">Your Mental Health Journey Matters</h2>
            <p className="text-white/90 mb-6">
              Take the next step in your wellness journey. Connect with support, learn new coping strategies, or simply check in with yourself.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/browse">
                <Button className="bg-white text-primary hover:bg-white/95" data-testid="button-find-support">
                  Find Support Now
                </Button>
              </Link>
              <Link href="/resources">
                <Button variant="outline" className="border-white text-white hover:bg-white hover:text-primary" data-testid="button-learn-more">
                  Learn Coping Skills
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
