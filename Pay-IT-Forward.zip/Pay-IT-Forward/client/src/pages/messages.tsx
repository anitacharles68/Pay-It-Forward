import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { MessageCircle, Search, Send, Users } from "lucide-react";
import Navigation from "@/components/navigation";
import MessageThread from "@/components/message-thread";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { User as UserType, Message } from "@shared/schema";

export default function Messages() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [newMessage, setNewMessage] = useState("");

  const { data: conversations = [], isLoading: conversationsLoading } = useQuery({
    queryKey: ['/api/conversations'],
    enabled: !!user,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ['/api/messages', selectedConversation],
    enabled: !!selectedConversation,
    refetchInterval: 5000, // Refresh every 5 seconds for real-time feel
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: { receiverId: string; content: string }) => {
      await apiRequest('POST', '/api/messages', messageData);
    },
    onSuccess: () => {
      setNewMessage("");
      queryClient.invalidateQueries({ queryKey: ['/api/messages', selectedConversation] });
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Failed to Send",
        description: "Could not send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedConversation) return;

    sendMessageMutation.mutate({
      receiverId: selectedConversation,
      content: newMessage.trim(),
    });
  };

  const filteredConversations = conversations.filter((conv: any) => {
    const fullName = `${conv.user.firstName} ${conv.user.lastName}`.toLowerCase();
    return fullName.includes(searchTerm.toLowerCase());
  });

  const selectedUser = conversations.find((conv: any) => conv.user.id === selectedConversation)?.user;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="md:ml-64 h-screen flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <h1 className="text-3xl font-bold text-foreground mb-2">Messages</h1>
          <p className="text-muted-foreground">
            Connect with your providers and support network
          </p>
        </div>

        <div className="flex-1 flex overflow-hidden">
          {/* Conversations List */}
          <div className="w-full md:w-1/3 lg:w-1/4 border-r border-border flex flex-col">
            {/* Search */}
            <div className="p-4 border-b border-border">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search conversations..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-conversations"
                />
              </div>
            </div>

            {/* Conversations */}
            <ScrollArea className="flex-1">
              {conversationsLoading ? (
                <div className="p-4 space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />
                  ))}
                </div>
              ) : filteredConversations.length === 0 ? (
                <div className="p-8 text-center">
                  <MessageCircle className="h-12 w-12 mx-auto mb-3 text-muted-foreground opacity-50" />
                  <p className="text-muted-foreground mb-4">
                    {searchTerm ? "No conversations found" : "No conversations yet"}
                  </p>
                  {!searchTerm && (
                    <p className="text-sm text-muted-foreground">
                      Start a conversation by booking a session with a provider
                    </p>
                  )}
                </div>
              ) : (
                <div className="p-2">
                  {filteredConversations.map((conversation: any) => (
                    <div
                      key={conversation.user.id}
                      className={`p-3 rounded-lg cursor-pointer hover:bg-muted/50 transition-colors ${
                        selectedConversation === conversation.user.id ? 'bg-muted' : ''
                      }`}
                      onClick={() => setSelectedConversation(conversation.user.id)}
                      data-testid={`conversation-${conversation.user.id}`}
                    >
                      <div className="flex items-start gap-3">
                        {conversation.user.profileImageUrl ? (
                          <img 
                            src={conversation.user.profileImageUrl} 
                            alt={`${conversation.user.firstName} ${conversation.user.lastName}`}
                            className="w-12 h-12 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                            <Users className="h-6 w-6 text-primary" />
                          </div>
                        )}
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <h3 className="font-medium truncate" data-testid={`text-user-name-${conversation.user.id}`}>
                              {conversation.user.firstName} {conversation.user.lastName}
                            </h3>
                            {conversation.unreadCount > 0 && (
                              <Badge variant="destructive" className="text-xs ml-2">
                                {conversation.unreadCount}
                              </Badge>
                            )}
                          </div>
                          
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="outline" className="text-xs">
                              {conversation.user.role === 'counselor' ? 'Licensed Counselor' : 
                               conversation.user.role === 'peer_specialist' ? 'Peer Specialist' : 'Client'}
                            </Badge>
                          </div>
                          
                          <p className="text-sm text-muted-foreground truncate" data-testid={`text-last-message-${conversation.user.id}`}>
                            {conversation.lastMessage?.content || "No messages yet"}
                          </p>
                          
                          {conversation.lastMessage && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(conversation.lastMessage.createdAt).toLocaleDateString()}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>

          {/* Message Thread */}
          <div className="flex-1 flex flex-col">
            {selectedConversation && selectedUser ? (
              <>
                {/* Thread Header */}
                <div className="p-4 border-b border-border">
                  <div className="flex items-center gap-3">
                    {selectedUser.profileImageUrl ? (
                      <img 
                        src={selectedUser.profileImageUrl} 
                        alt={`${selectedUser.firstName} ${selectedUser.lastName}`}
                        className="w-10 h-10 rounded-full object-cover"
                        data-testid="img-selected-user-avatar"
                      />
                    ) : (
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                        <Users className="h-5 w-5 text-primary" />
                      </div>
                    )}
                    
                    <div>
                      <h2 className="font-semibold" data-testid="text-selected-user-name">
                        {selectedUser.firstName} {selectedUser.lastName}
                      </h2>
                      <Badge variant="outline" className="text-xs">
                        {selectedUser.role === 'counselor' ? 'Licensed Counselor' : 
                         selectedUser.role === 'peer_specialist' ? 'Peer Specialist' : 'Client'}
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* Messages */}
                <MessageThread 
                  messages={messages}
                  currentUserId={user?.id || ''}
                  isLoading={messagesLoading}
                />

                {/* Message Input */}
                <form onSubmit={handleSendMessage} className="p-4 border-t border-border">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Type your message..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      disabled={sendMessageMutation.isPending}
                      data-testid="input-new-message"
                    />
                    <Button 
                      type="submit"
                      disabled={!newMessage.trim() || sendMessageMutation.isPending}
                      data-testid="button-send-message"
                    >
                      {sendMessageMutation.isPending ? (
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                      ) : (
                        <Send className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </form>
              </>
            ) : (
              /* Empty State */
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <MessageCircle className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                  <h3 className="text-lg font-semibold mb-2">Select a Conversation</h3>
                  <p className="text-muted-foreground">
                    Choose a conversation from the list to start messaging
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
