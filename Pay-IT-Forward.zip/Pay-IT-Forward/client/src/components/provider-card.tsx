import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Calendar, MessageCircle, Users, UserRound, Clock, DollarSign } from "lucide-react";
import { Link } from "wouter";
import type { User } from "@shared/schema";

interface ProviderCardProps {
  provider: User;
}

export default function ProviderCard({ provider }: ProviderCardProps) {
  const getRoleDisplay = (role: string) => {
    switch (role) {
      case 'counselor': return 'Licensed Counselor';
      case 'peer_specialist': return 'Peer Specialist';
      default: return role;
    }
  };

  const getRoleIcon = (role: string) => {
    return role === 'counselor' ? UserRound : Users;
  };

  const RoleIcon = getRoleIcon(provider.role || 'client');

  const getRate = () => {
    if (provider.role === 'counselor') {
      return provider.hourlyRate ? `$${provider.hourlyRate}/session` : '$50-70/session';
    } else if (provider.role === 'peer_specialist') {
      return provider.hourlyRate ? `$${provider.hourlyRate}/hour` : '$20/hour';
    }
    return null;
  };

  return (
    <Card className="card-hover h-full" data-testid={`provider-card-${provider.id}`}>
      <CardContent className="p-6">
        {/* Provider Header */}
        <div className="flex items-start space-x-4 mb-4">
          <div className="relative">
            {provider.profileImageUrl ? (
              <img 
                src={provider.profileImageUrl} 
                alt={`${provider.firstName} ${provider.lastName}`}
                className="w-16 h-16 rounded-full object-cover"
                data-testid={`img-provider-${provider.id}`}
              />
            ) : (
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                <RoleIcon className="h-8 w-8 text-primary" />
              </div>
            )}
            {provider.isAvailable && (
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 border-2 border-white rounded-full" />
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-bold truncate" data-testid={`text-provider-name-${provider.id}`}>
              {provider.firstName} {provider.lastName}
            </h3>
            <Badge 
              variant={provider.role === 'counselor' ? 'default' : 'secondary'} 
              className="mb-2"
              data-testid={`badge-provider-role-${provider.id}`}
            >
              {getRoleDisplay(provider.role || 'client')}
            </Badge>
            
            {provider.licenseNumber && (
              <p className="text-xs text-muted-foreground">
                License: {provider.licenseNumber}
              </p>
            )}
          </div>
        </div>

        {/* Bio */}
        {provider.bio && (
          <p className="text-sm text-muted-foreground mb-4 line-clamp-3" data-testid={`text-provider-bio-${provider.id}`}>
            {provider.bio}
          </p>
        )}

        {/* Specialties */}
        {provider.specialties && provider.specialties.length > 0 && (
          <div className="mb-4">
            <div className="flex flex-wrap gap-1">
              {provider.specialties.slice(0, 3).map((specialty, index) => (
                <Badge key={index} variant="outline" className="text-xs" data-testid={`badge-specialty-${provider.id}-${index}`}>
                  {specialty}
                </Badge>
              ))}
              {provider.specialties.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{provider.specialties.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
          <div className="flex items-center gap-4">
            {provider.yearsExperience && (
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {provider.yearsExperience} exp
              </div>
            )}
            <div className="flex items-center gap-1">
              <Star className="h-3 w-3 text-yellow-500" />
              4.8
            </div>
          </div>
          
          {getRate() && (
            <div className="flex items-center gap-1 font-medium text-foreground">
              <DollarSign className="h-3 w-3" />
              {getRate()}
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          <Link href={`/booking/${provider.id}`} className="flex-1">
            <Button 
              className="w-full" 
              size="sm"
              disabled={!provider.isAvailable}
              data-testid={`button-book-${provider.id}`}
            >
              <Calendar className="h-4 w-4 mr-1" />
              {provider.isAvailable ? 'Book Session' : 'Unavailable'}
            </Button>
          </Link>
          
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              // TODO: Implement direct messaging
              window.location.href = '/messages';
            }}
            data-testid={`button-message-${provider.id}`}
          >
            <MessageCircle className="h-4 w-4" />
          </Button>
        </div>

        {/* Availability Indicator */}
        <div className="mt-3 flex items-center gap-2 text-xs">
          <div className={`w-2 h-2 rounded-full ${provider.isAvailable ? 'bg-green-500' : 'bg-red-500'}`} />
          <span className="text-muted-foreground">
            {provider.isAvailable ? 'Available for new clients' : 'Currently unavailable'}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
