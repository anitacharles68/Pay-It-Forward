import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Heart, Menu, Home, Users, Calendar, MessageCircle, BookOpen, User, Settings, LogOut } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function Navigation() {
  const { user } = useAuth();
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/browse", label: "Find Support", icon: Users },
    { href: "/dashboard", label: "Appointments", icon: Calendar },
    { href: "/messages", label: "Messages", icon: MessageCircle },
    { href: "/resources", label: "Resources", icon: BookOpen },
  ];

  const isActive = (href: string) => {
    if (href === "/" && location === "/") return true;
    if (href !== "/" && location.startsWith(href)) return true;
    return false;
  };

  const getRoleDisplay = (role: string) => {
    switch (role) {
      case 'counselor': return 'Licensed Counselor';
      case 'peer_specialist': return 'Peer Specialist';
      default: return 'Client';
    }
  };

  const NavContent = () => (
    <>
      <div className="flex items-center space-x-3 mb-8">
        <Heart className="text-primary text-2xl" />
        <span className="text-xl font-bold text-foreground">Pay It Forward</span>
      </div>

      <nav className="space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <Button
                variant={isActive(item.href) ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setIsOpen(false)}
                data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
              >
                <Icon className="mr-2 h-4 w-4" />
                {item.label}
              </Button>
            </Link>
          );
        })}
      </nav>

      <div className="mt-8 pt-8 border-t border-border">
        <div className="flex items-center space-x-3 mb-4">
          {user?.profileImageUrl ? (
            <img 
              src={user.profileImageUrl} 
              alt="Profile"
              className="w-10 h-10 rounded-full object-cover"
              data-testid="img-user-avatar"
            />
          ) : (
            <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
              <User className="h-5 w-5 text-primary" />
            </div>
          )}
          <div className="flex-1 min-w-0">
            <div className="font-medium truncate" data-testid="text-user-name">
              {user?.firstName} {user?.lastName}
            </div>
            <Badge variant="secondary" className="text-xs">
              {getRoleDisplay(user?.role || 'client')}
            </Badge>
          </div>
        </div>

        <div className="space-y-2">
          <Link href="/profile">
            <Button 
              variant="ghost" 
              className="w-full justify-start"
              onClick={() => setIsOpen(false)}
              data-testid="button-profile"
            >
              <Settings className="mr-2 h-4 w-4" />
              Profile Settings
            </Button>
          </Link>
          
          <Button 
            variant="ghost" 
            className="w-full justify-start text-destructive hover:text-destructive"
            onClick={() => window.location.href = '/api/logout'}
            data-testid="button-logout"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Sign Out
          </Button>
        </div>
      </div>
    </>
  );

  return (
    <>
      {/* Desktop Navigation */}
      <div className="hidden md:block w-64 bg-card border-r border-border h-screen fixed left-0 top-0 z-40">
        <div className="p-6 h-full flex flex-col">
          <NavContent />
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="md:hidden bg-card border-b border-border px-4 py-3 sticky top-0 z-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Heart className="text-primary text-xl" />
            <span className="text-lg font-bold text-foreground">Pay It Forward</span>
          </div>
          
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="sm" data-testid="button-mobile-menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64">
              <NavContent />
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Content Spacer for Desktop */}
      <div className="hidden md:block w-64" />
    </>
  );
}
