import {
  users,
  appointments,
  messages,
  resources,
  type User,
  type UpsertUser,
  type InsertUser,
  type Appointment,
  type InsertAppointment,
  type Message,
  type InsertMessage,
  type Resource,
  type InsertResource,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc, ilike } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserProfile(id: string, updates: Partial<InsertUser>): Promise<User>;
  updateUserStripeInfo(id: string, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User>;
  
  // Provider operations
  getProviders(role?: 'counselor' | 'peer_specialist', specialty?: string): Promise<User[]>;
  getProviderById(id: string): Promise<User | undefined>;
  
  // Appointment operations
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  getAppointmentsByUser(userId: string, role: 'client' | 'provider'): Promise<Appointment[]>;
  getAppointmentById(id: string): Promise<Appointment | undefined>;
  updateAppointmentStatus(id: string, status: string): Promise<Appointment>;
  
  // Message operations
  sendMessage(message: InsertMessage): Promise<Message>;
  getMessagesBetweenUsers(user1Id: string, user2Id: string): Promise<Message[]>;
  getConversations(userId: string): Promise<{ user: User; lastMessage: Message; unreadCount: number }[]>;
  markMessageAsRead(messageId: string): Promise<Message>;
  
  // Resource operations
  getResources(category?: string): Promise<Resource[]>;
  createResource(resource: InsertResource): Promise<Resource>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserProfile(id: string, updates: Partial<InsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserStripeInfo(id: string, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User> {
    const updateData: any = { stripeCustomerId, updatedAt: new Date() };
    if (stripeSubscriptionId) {
      updateData.stripeSubscriptionId = stripeSubscriptionId;
    }
    
    const [user] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Provider operations
  async getProviders(role?: 'counselor' | 'peer_specialist', specialty?: string): Promise<User[]> {
    let query = db.select().from(users).where(eq(users.isAvailable, true));
    
    if (role) {
      query = query.where(eq(users.role, role));
    } else {
      query = query.where(or(eq(users.role, 'counselor'), eq(users.role, 'peer_specialist')));
    }
    
    const providers = await query;
    
    if (specialty) {
      return providers.filter(provider => 
        provider.specialties?.some(s => s.toLowerCase().includes(specialty.toLowerCase()))
      );
    }
    
    return providers;
  }

  async getProviderById(id: string): Promise<User | undefined> {
    const [provider] = await db
      .select()
      .from(users)
      .where(and(
        eq(users.id, id),
        or(eq(users.role, 'counselor'), eq(users.role, 'peer_specialist'))
      ));
    return provider;
  }

  // Appointment operations
  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const [newAppointment] = await db
      .insert(appointments)
      .values(appointment)
      .returning();
    return newAppointment;
  }

  async getAppointmentsByUser(userId: string, role: 'client' | 'provider'): Promise<Appointment[]> {
    const whereClause = role === 'client' 
      ? eq(appointments.clientId, userId)
      : eq(appointments.providerId, userId);
      
    return await db
      .select()
      .from(appointments)
      .where(whereClause)
      .orderBy(desc(appointments.startTime));
  }

  async getAppointmentById(id: string): Promise<Appointment | undefined> {
    const [appointment] = await db
      .select()
      .from(appointments)
      .where(eq(appointments.id, id));
    return appointment;
  }

  async updateAppointmentStatus(id: string, status: string): Promise<Appointment> {
    const [appointment] = await db
      .update(appointments)
      .set({ status })
      .where(eq(appointments.id, id))
      .returning();
    return appointment;
  }

  // Message operations
  async sendMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db
      .insert(messages)
      .values(message)
      .returning();
    return newMessage;
  }

  async getMessagesBetweenUsers(user1Id: string, user2Id: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(
        or(
          and(eq(messages.senderId, user1Id), eq(messages.receiverId, user2Id)),
          and(eq(messages.senderId, user2Id), eq(messages.receiverId, user1Id))
        )
      )
      .orderBy(messages.createdAt);
  }

  async getConversations(userId: string): Promise<{ user: User; lastMessage: Message; unreadCount: number }[]> {
    // This is a simplified implementation - in production you'd want to optimize this query
    const userMessages = await db
      .select()
      .from(messages)
      .where(or(eq(messages.senderId, userId), eq(messages.receiverId, userId)))
      .orderBy(desc(messages.createdAt));

    const conversationMap = new Map();
    
    for (const message of userMessages) {
      const otherUserId = message.senderId === userId ? message.receiverId : message.senderId;
      
      if (!conversationMap.has(otherUserId)) {
        const [otherUser] = await db.select().from(users).where(eq(users.id, otherUserId));
        if (otherUser) {
          conversationMap.set(otherUserId, {
            user: otherUser,
            lastMessage: message,
            unreadCount: 0,
          });
        }
      }
    }

    // Calculate unread counts
    for (const [otherUserId, conversation] of conversationMap) {
      const unreadMessages = await db
        .select()
        .from(messages)
        .where(
          and(
            eq(messages.senderId, otherUserId),
            eq(messages.receiverId, userId),
            eq(messages.isRead, false)
          )
        );
      conversation.unreadCount = unreadMessages.length;
    }

    return Array.from(conversationMap.values());
  }

  async markMessageAsRead(messageId: string): Promise<Message> {
    const [message] = await db
      .update(messages)
      .set({ isRead: true })
      .where(eq(messages.id, messageId))
      .returning();
    return message;
  }

  // Resource operations
  async getResources(category?: string): Promise<Resource[]> {
    let query = db.select().from(resources).orderBy(desc(resources.createdAt));
    
    if (category) {
      query = query.where(eq(resources.category, category));
    }
    
    return await query;
  }

  async createResource(resource: InsertResource): Promise<Resource> {
    const [newResource] = await db
      .insert(resources)
      .values(resource)
      .returning();
    return newResource;
  }
}

export const storage = new DatabaseStorage();
